package com.example.zad2.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class FileService {

    private static final Path FILE = Paths.get("output", "datetime.txt");
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public void writeCurrentDateTimeToFile() {
        try {
            Files.createDirectories(FILE.getParent());

            String now = LocalDateTime.now().format(FORMATTER) + System.lineSeparator();

            Files.write(FILE, now.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

            System.out.println("Zapisano datę i godzinę do pliku: " + FILE.toAbsolutePath());

        } catch (AccessDeniedException e) {
            System.err.println("Brak uprawnień do zapisu pliku: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Błąd I/O podczas zapisu pliku: " + e.getMessage());
            e.printStackTrace();
        } catch (SecurityException e) {
            System.err.println("Brak uprawnień (SecurityException): " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Nieoczekiwany błąd podczas zapisu: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void readAndPrintFile() {
        try {
            if (!Files.exists(FILE)) {
                System.err.println("Plik nie istnieje: " + FILE.toAbsolutePath());
                return;
            }

            System.out.println("Zawartość pliku " + FILE.toAbsolutePath() + ":");
            Files.lines(FILE).forEach(System.out::println);

        } catch (AccessDeniedException e) {
            System.err.println("Brak uprawnień do odczytu pliku: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Błąd I/O podczas odczytu pliku: " + e.getMessage());
            e.printStackTrace();
        } catch (SecurityException e) {
            System.err.println("Brak uprawnień (SecurityException): " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Nieoczekiwany błąd podczas odczytu: " + e.getMessage());
            e.printStackTrace();
        }
    }
}