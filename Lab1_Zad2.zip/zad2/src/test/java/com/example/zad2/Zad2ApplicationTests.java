package com.example.zad2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zad2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
