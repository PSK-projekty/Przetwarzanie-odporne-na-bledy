package com.example.lab2;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import okhttp3.logging.HttpLoggingInterceptor;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;

public final class Lab2Application {

    public static final class Post {
        public int userId;
        public int id;
        public String title;
        public String body;
    }

    public static void main(String[] args) {
        OkHttpClient client = new OkHttpClient.Builder()
                .callTimeout(Duration.ofSeconds(30))
                .connectTimeout(Duration.ofSeconds(10))
                .readTimeout(Duration.ofSeconds(20))
                .writeTimeout(Duration.ofSeconds(20))
                .addInterceptor(new RequestResponseLogger())
                .addInterceptor(new HttpLoggingInterceptor(System.out::println)
                        .setLevel(HttpLoggingInterceptor.Level.BASIC))
                .build();

        HttpUrl url = new HttpUrl.Builder()
                .scheme("https")
                .host("jsonplaceholder.typicode.com")
                .addPathSegment("posts")
                .addQueryParameter("userId", "1")
                .build();

        Request request = new Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected HTTP code " + response.code() + ": " + response.message());
            }
            String body = response.body() != null ? response.body().string() : "";
            ObjectMapper mapper = new ObjectMapper();
            List<Post> posts = mapper.readValue(body, new TypeReference<List<Post>>() {});
            System.out.println("\n== Wybrane informacje z odpowiedzi ==");
            for (Post p : posts) {
                System.out.printf("Post #%d (userId=%d): %s%n", p.id, p.userId, preview(p.title));
            }
        } catch (IOException e) {
            System.err.println("Błąd komunikacji HTTP: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }

    private static String preview(String s) {
        if (s == null) return "";
        String t = s.replace("\n", " ").trim();
        return t.length() > 120 ? t.substring(0, 120) + "…" : t;
    }

    private static final class RequestResponseLogger implements Interceptor {
        @Override public Response intercept(Chain chain) throws IOException {
            Request req = chain.request();
            long start = System.nanoTime();

            System.out.println("\n⇢⇢⇢ REQUEST");
            System.out.println(req.method() + " " + req.url());
            for (int i = 0; i < req.headers().size(); i++) {
                System.out.println(req.headers().name(i) + ": " + req.headers().value(i));
            }

            Response res;
            try {
                res = chain.proceed(req);
            } catch (IOException ioe) {
                System.out.println("⇠⇠⇠ RESPONSE ERROR: " + ioe.getMessage());
                throw ioe;
            }

            long tookMs = Math.round((System.nanoTime() - start) / 1_000_000.0);
            System.out.println("\n⇠⇠⇠ RESPONSE");
            System.out.println("Status: " + res.code() + " " + res.message());
            System.out.println("URL:    " + res.request().url());
            System.out.println("Czas:   " + tookMs + " ms");
            System.out.println("Nagłówki odpowiedzi:");
            for (int i = 0; i < res.headers().size(); i++) {
                System.out.println("  " + res.headers().name(i) + ": " + res.headers().value(i));
            }

            ResponseBody body = res.body();
            if (body != null) {
                String preview = body.source().peek().readUtf8Line();
                if (preview != null) {
                    byte[] bytes = preview.getBytes(StandardCharsets.UTF_8);
                    String msg = bytes.length > 512 ? new String(bytes, 0, 512, StandardCharsets.UTF_8) + "…" : preview;
                    System.out.println("Podgląd treści: " + msg);
                }
            }
            return res;
        }
    }
}
